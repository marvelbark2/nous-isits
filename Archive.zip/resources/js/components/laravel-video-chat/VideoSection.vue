<template>
    <div>
        <video  class="img-responsive" autoplay id='remoteVideo'>
            Your browser does not support the video tag.
        </video>
        <video  class="img-responsive" autoplay id='localVideo'>
            Your browser does not support the video tag.
        </video>
    </div>
</template>

<script>
    export default {
        data() {
            return {}
        }
    }
</script>