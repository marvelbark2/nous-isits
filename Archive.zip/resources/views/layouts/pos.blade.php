@include('layouts.header')



@include('layouts.sidebar')
<section class="content">
    <div class="container-fluid">

@section('content')
@show
    </div>
</section>

@include('layouts.footer')
