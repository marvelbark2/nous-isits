<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mnote extends Model
{

}
