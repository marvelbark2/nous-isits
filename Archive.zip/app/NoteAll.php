<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoteAll extends Model
{
    //
}
